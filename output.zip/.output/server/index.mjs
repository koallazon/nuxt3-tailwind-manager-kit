globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node-fetch-native/polyfill';
import 'ufo';
export { h as handler } from './chunks/nitro/aws-lambda.mjs';
import 'ofetch';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
//# sourceMappingURL=index.mjs.map
