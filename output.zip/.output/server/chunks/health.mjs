import { d as defineEventHandler } from './nitro/aws-lambda.mjs';
import 'node-fetch-native/polyfill';
import 'ufo';
import 'ofetch';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';

const health = defineEventHandler(() => {
  return `success - ${new Date().toLocaleTimeString()}`;
});

export { health as default };
//# sourceMappingURL=health.mjs.map
