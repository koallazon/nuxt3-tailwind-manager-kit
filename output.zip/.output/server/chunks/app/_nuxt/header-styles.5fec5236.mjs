const header_vue_vue_type_style_index_0_scoped_6e0cbb33_lang = ".navbar-default[data-v-6e0cbb33]{--color-text-active:#fff;--color-text-hover:#fff;--color-fill-hover:#1d4ed8;--color-fill-active:#1d4ed8;--color-fill-active-dark:#eee}";

const headerStyles_5fec5236 = [header_vue_vue_type_style_index_0_scoped_6e0cbb33_lang];

export { headerStyles_5fec5236 as default };
//# sourceMappingURL=header-styles.5fec5236.mjs.map
