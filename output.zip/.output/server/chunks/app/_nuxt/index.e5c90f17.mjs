import { _ as _sfc_main$1 } from './pageContainer.8da92a3b.mjs';
import { a as useHead } from '../server.mjs';
import { defineComponent, mergeProps, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'ufo';
import '../../nitro/aws-lambda.mjs';
import 'node-fetch-native/polyfill';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'cookie-es';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const title = "\uD648";
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_page_container = _sfc_main$1;
      _push(ssrRenderComponent(_component_page_container, mergeProps({ title }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2${_scopeId}>\uC5EC\uAE30\uB294 ${ssrInterpolate(title)}\uC785\uB2C8\uB2E4.</h2><div${_scopeId}>${ssrInterpolate(_ctx.$hello("world"))}</div>`);
          } else {
            return [
              createVNode("h2", null, "\uC5EC\uAE30\uB294 " + toDisplayString(title) + "\uC785\uB2C8\uB2E4."),
              createVNode("div", null, toDisplayString(_ctx.$hello("world")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.e5c90f17.mjs.map
