import { a as useHead, c as useAppStore, b as __nuxt_component_2, _ as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, defineComponent, mergeProps, ref, unref, withCtx, createTextVNode, toDisplayString, computed } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'ufo';
import '../../nitro/aws-lambda.mjs';
import 'node-fetch-native/polyfill';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'cookie-es';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "gnb",
  __ssrInlineRender: true,
  setup(__props) {
    const menus = ref([
      {
        text: "home",
        to: "/"
      },
      {
        text: "dashboard",
        to: "/dashboard"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-80 h-screen border-r border-r-skin-base p-5" }, _attrs))}><nav class="w-full flex flex-col items-start sm:gap-1"><!--[-->`);
      ssrRenderList(unref(menus), (menu) => {
        _push(ssrRenderComponent(_component_NuxtLink, {
          key: menu.text,
          to: menu.to,
          class: "px-4 py-2 rounded-full w-full sm:w-auto text-skin-base hover:text-skin-hover hover:bg-skin-fill-hover transition duration-200 font-medium",
          "exact-active-class": "bg-skin-fill-active text-skin-active"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(menu.text)}`);
            } else {
              return [
                createTextVNode(toDisplayString(menu.text), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></nav></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/gnb.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "header",
  __ssrInlineRender: true,
  setup(__props) {
    const appStore = useAppStore();
    const oppositeTheme = computed(() => {
      return appStore.isDark ? "light" : "dark";
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "navbar-default bg-gray-300 dark:bg-gray-700 text-skin-base px-6 py-3 border-b sticky top-0" }, _attrs))} data-v-6e0cbb33><div class="container mx-auto pl-4 pr-2 sm:px-0 flex flex-row items-center gap-4 justify-between" data-v-6e0cbb33>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "font-bold text-skin-base text-lg"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \uAD00\uB9AC\uC790 \uC0AC\uC774\uD2B8 `);
          } else {
            return [
              createTextVNode(" \uAD00\uB9AC\uC790 \uC0AC\uC774\uD2B8 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="text-black dark:text-white" data-v-6e0cbb33><button type="button" data-v-6e0cbb33><span class="material-symbols-outlined" data-v-6e0cbb33>${ssrInterpolate(`${unref(oppositeTheme)}_mode`)}</span></button></div></div></header>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/header.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-6e0cbb33"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full h-15 mt-auto bg-gray-300 dark:bg-gray-700 py-5 px-8" }, _attrs))}> \xA9 2023 Hanatour. All rights reserved. </div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\uAE30\uBCF8"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppGnb = _sfc_main$3;
      const _component_AppHeader = __nuxt_component_1;
      const _component_NuxtPage = __nuxt_component_2;
      const _component_AppFooter = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full flex flex-row mx-auto" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_AppGnb, null, null, _parent));
      _push(`<div class="w-full flex flex-col justify-start">`);
      _push(ssrRenderComponent(_component_AppHeader, null, null, _parent));
      _push(`<main class="p-5">`);
      _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
      _push(`</main>`);
      _push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default.18657a55.mjs.map
