const client_manifest = {
  "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.223f2e70.js",
    "src": "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "layouts/anonymous.vue",
      "layouts/default.vue",
      "virtual:nuxt:/Users/tglee/Documents/study/nuxt3-tailwind-manager-kit/.nuxt/error-component.mjs"
    ],
    "css": [
      "entry.498e5b2e.css"
    ]
  },
  "entry.498e5b2e.css": {
    "file": "entry.498e5b2e.css",
    "resourceType": "style"
  },
  "virtual:nuxt:/Users/tglee/Documents/study/nuxt3-tailwind-manager-kit/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.e17483ec.js",
    "src": "virtual:nuxt:/Users/tglee/Documents/study/nuxt3-tailwind-manager-kit/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/contents/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.5d5ad4c6.js",
    "src": "pages/contents/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.532f90b9.js",
    "src": "pages/dashboard.vue",
    "isDynamicEntry": true,
    "imports": [
      "_pageContainer.vue_vue_type_script_setup_true_lang.3724b4bd.js",
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_pageContainer.vue_vue_type_script_setup_true_lang.3724b4bd.js": {
    "resourceType": "script",
    "module": true,
    "file": "pageContainer.vue_vue_type_script_setup_true_lang.3724b4bd.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b9dea730.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_pageContainer.vue_vue_type_script_setup_true_lang.3724b4bd.js",
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.74028ceb.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/anonymous.vue": {
    "resourceType": "script",
    "module": true,
    "file": "anonymous.cea2a159.js",
    "src": "layouts/anonymous.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ]
  },
  "__plugin-vue_export-helper.a1a6add7.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.a1a6add7.js"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.c0da5d41.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": [
      "default.b0449516.css"
    ]
  },
  "default.b0449516.css": {
    "file": "default.b0449516.css",
    "resourceType": "style"
  },
  "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.498e5b2e.css",
    "src": "node_modules/.pnpm/nuxt@3.0.0_pwpk577hwtuwgvziewj6f5zxl4/node_modules/nuxt/dist/app/entry.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.b0449516.css",
    "src": "layouts/default.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
