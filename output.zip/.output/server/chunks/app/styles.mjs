const interopDefault = r => r.default || r || [];
const styles = {
  "components/app/header.vue": () => import('./_nuxt/header-styles.5fec5236.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
